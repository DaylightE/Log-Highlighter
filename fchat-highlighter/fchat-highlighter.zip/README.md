F-List Log Highlighter (Firefox)
================================

Highlights F-List report logs by re-rendering the page with clearer metadata and color-coding.

Match URL: https://www.f-list.net/fchat/getLog.php?log=<id>

Features
- Highlight senders:
  - Reporting user messages: red background
  - Log submitted by messages: blue background
  - Additional names: green background (comma-separated input)
- Header details:
  - Shows “Log submitted by”, “Log submitted on”, “Reporting user” and “Tab”
  - Colors the submitter and reporter names by profile gender:
    - None: Grey, Female: Pink, Male: default link blue, Herm: Dark purple, Male-Herm: Dark blue, Shemale: Light purple, Cunt-Boy: Green, Transgender: Orange
    - Uses “Gender:” from the user’s profile page
  - Adds a star to the Tab when the trailing slug in parentheses is on the provided list (e.g. Ageplay (ageplay) → ★Ageplay (ageplay))
  - Collapse/expand header controls
- Time tools:
  - Convert all [HH:MM] and [YYYY-MM-DD HH:MM] (with optional AM/PM) to local time
  - Remembers preference per browser via localStorage
- Extras:
  - Computes and displays the maximum [icon]/[eicon] count for the reported user
  - One-time disable via `fhl_off=1` URL param or the close button

How it works
- Parses page text to extract labels and group messages by header lines like “[HH:MM] …” or “[YYYY-MM-DD HH:MM] …”.
- Re-renders as blocks with preserved text and applied highlights.
- Fetches profile pages client-side to read the “Gender:” field and colorize the names.

Install (temporary, for development)
1) Open Firefox and go to: about:debugging#/runtime/this-firefox
2) Click "Load Temporary Add-on"
3) Select this folder's `manifest.json`
4) Visit a log page (e.g. https://www.f-list.net/fchat/getLog.php?log=173488)

Notes
- This extension only reads and re-renders the log page content client-side.
- No data is sent anywhere; it does not require special permissions.


Chrome Version
==============
A Chrome-ready copy is in `../fchat-highlighter-chrome/`.

- Load in Chrome (dev): go to `chrome://extensions`, enable Developer Mode, click "Load unpacked", select `fchat-highlighter-chrome/`.
- Package for the Chrome Web Store: zip the contents of `fchat-highlighter-chrome/` (not the parent folder) and upload.
- The Chrome manifest omits Firefox-only `browser_specific_settings` and reuses the same `content.js` and `icon-128.png`.


What’s New
----------
1.4
- Gender-based name colors in header; names default to grey until loaded; Male stays default link blue
- “Tab” shown under Reporting user, with star (★) when its parentheses slug matches the provided list (e.g., ageplay)
- AM/PM timestamp support and inline timestamp handling in Report text
- ASCII-only header controls to avoid encoding issues

1.3
- Initial public version with highlighting, extras input, and time conversion
